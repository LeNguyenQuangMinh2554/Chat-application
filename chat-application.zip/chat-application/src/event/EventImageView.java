package event;

import javax.swing.Icon;

public interface EventImageView {

    public void viewImage(Icon image);

    public void saveImage(Icon image);
}
